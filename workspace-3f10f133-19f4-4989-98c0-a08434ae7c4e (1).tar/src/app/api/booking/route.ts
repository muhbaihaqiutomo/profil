import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { 
      packageId, 
      packageName, 
      name, 
      email, 
      phone, 
      departureDate, 
      participants, 
      specialRequests 
    } = body

    // Validate required fields
    if (!packageId || !packageName || !name || !email || !phone || !departureDate || !participants) {
      return NextResponse.json(
        { error: 'Semua field wajib harus diisi' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      )
    }

    // Validate phone format (basic Indonesian phone number)
    const phoneRegex = /^(\+62|62|0)[0-9]{9,13}$/
    if (!phoneRegex.test(phone.replace(/[-\s]/g, ''))) {
      return NextResponse.json(
        { error: 'Format nomor telepon tidak valid' },
        { status: 400 }
      )
    }

    // Validate participants
    if (participants < 1 || participants > 50) {
      return NextResponse.json(
        { error: 'Jumlah peserta harus antara 1-50 orang' },
        { status: 400 }
      )
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Generate booking confirmation using AI
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Anda adalah asisten pemesanan untuk Insan Tour Alam. Buat konfirmasi pemesanan yang profesional dan detail.'
        },
        {
          role: 'user',
          content: `Buat konfirmasi pemesanan untuk:\n\nPaket: ${packageName}\nNama: ${name}\nEmail: ${email}\nTelepon: ${phone}\nTanggal Keberangkatan: ${departureDate}\nJumlah Peserta: ${participants}\nPermintaan Khusus: ${specialRequests || 'Tidak ada'}\n\nBuat konfirmasi yang mencakup detail pemesanan, informasi pembayaran, dan langkah selanjutnya.`
        }
      ],
      temperature: 0.3,
      max_tokens: 800
    })

    const bookingConfirmation = aiResponse.choices[0]?.message?.content || 'Pemesanan berhasil dibuat.'

    // Generate booking ID
    const bookingId = `ITA-${Date.now()}-${Math.random().toString(36).substr(2, 9).toUpperCase()}`

    // Calculate total price (this would normally come from database)
    const packagePrices: { [key: string]: number } = {
      '1': 2500000, // Bali 4H3M
      '2': 8500000, // Raja Ampat 7H6M
      '3': 25000000, // Umrah 15H14M
    }
    
    const basePrice = packagePrices[packageId] || 0
    const totalPrice = basePrice * participants

    // Here you would typically:
    // 1. Save booking to database
    // 2. Send booking confirmation email
    // 3. Generate invoice
    // 4. Update package availability
    // 5. Send notification to admin

    // Log the booking
    console.log('New booking:', {
      bookingId,
      packageId,
      packageName,
      name,
      email,
      phone,
      departureDate,
      participants,
      totalPrice,
      specialRequests,
      timestamp: new Date().toISOString()
    })

    return NextResponse.json({
      success: true,
      bookingId,
      message: 'Pemesanan berhasil! Kami akan menghubungi Anda untuk konfirmasi.',
      totalPrice,
      aiResponse: bookingConfirmation,
      nextSteps: [
        'Tim kami akan menghubungi Anda dalam 1x24 jam',
        'Persiapkan dokumen yang diperlukan (KTP, Paspor, dll)',
        'Lakukan pembayaran sesuai instruksi yang akan dikirim via email'
      ]
    })

  } catch (error) {
    console.error('Booking error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat memproses pemesanan. Silakan coba lagi.' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Booking API endpoint',
    methods: ['POST'],
    usage: 'POST /api/booking with JSON body: {packageId, packageName, name, email, phone, departureDate, participants, specialRequests}'
  })
}