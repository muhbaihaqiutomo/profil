import { NextRequest, NextResponse } from 'next/server'
import ZAI from 'z-ai-web-dev-sdk'

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, email, subject, message } = body

    // Validate required fields
    if (!name || !email || !subject || !message) {
      return NextResponse.json(
        { error: 'Semua field harus diisi' },
        { status: 400 }
      )
    }

    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    if (!emailRegex.test(email)) {
      return NextResponse.json(
        { error: 'Format email tidak valid' },
        { status: 400 }
      )
    }

    // Initialize ZAI SDK
    const zai = await ZAI.create()

    // Generate a professional response using AI
    const aiResponse = await zai.chat.completions.create({
      messages: [
        {
          role: 'system',
          content: 'Anda adalah asisten customer service untuk Insan Tour Alam. Berikan respons yang profesional, ramah, dan informatif untuk pertanyaan pelanggan.'
        },
        {
          role: 'user',
          content: `Nama: ${name}\nEmail: ${email}\nSubjek: ${subject}\nPesan: ${message}\n\nBerikan respons yang sesuai untuk pertanyaan ini.`
        }
      ],
      temperature: 0.7,
      max_tokens: 500
    })

    const responseMessage = aiResponse.choices[0]?.message?.content || 'Terima kasih atas pesan Anda. Kami akan segera menghubungi Anda.'

    // Here you would typically:
    // 1. Save the contact message to database
    // 2. Send email notification to admin
    // 3. Send confirmation email to customer
    // 4. Maybe integrate with CRM system

    // For now, we'll just log the contact
    console.log('New contact message:', {
      name,
      email,
      subject,
      message,
      timestamp: new Date().toISOString()
    })

    return NextResponse.json({
      success: true,
      message: 'Pesan Anda telah terkirim. Kami akan segera menghubungi Anda.',
      aiResponse: responseMessage
    })

  } catch (error) {
    console.error('Contact form error:', error)
    return NextResponse.json(
      { error: 'Terjadi kesalahan saat mengirim pesan. Silakan coba lagi.' },
      { status: 500 }
    )
  }
}

export async function GET() {
  return NextResponse.json({
    message: 'Contact API endpoint',
    methods: ['POST'],
    usage: 'POST /api/contact with JSON body: {name, email, subject, message}'
  })
}