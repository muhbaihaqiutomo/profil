'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Star, MapPin, Calendar, Users, Phone, MessageCircle, Menu, X, Plane, Hotel, Camera, Shield, CheckCircle, AlertCircle } from 'lucide-react'
import Link from 'next/link'

export default function Home() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })
  const [bookingForm, setBookingForm] = useState({
    packageId: '',
    packageName: '',
    name: '',
    email: '',
    phone: '',
    departureDate: '',
    participants: 1,
    specialRequests: ''
  })
  const [showBookingModal, setShowBookingModal] = useState(false)
  const [selectedPackage, setSelectedPackage] = useState<any>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [notification, setNotification] = useState<{
    type: 'success' | 'error'
    message: string
  } | null>(null)

  const heroImages = [
    {
      url: '/api/placeholder?width=1920&height=1080',
      title: 'Wisata Alam Indonesia',
      subtitle: 'Jelajahi keindahan alam Nusantara'
    },
    {
      url: '/api/placeholder?width=1920&height=1080',
      title: 'Umrah & Wisata Religi',
      subtitle: 'Perjalanan spiritual yang berkesan'
    },
    {
      url: '/api/placeholder?width=1920&height=1080',
      title: 'Destinasi Internasional',
      subtitle: 'Dunia dalam genggaman Anda'
    }
  ]

  const packages = [
    {
      id: 1,
      title: 'Paket Bali 4H3M',
      price: 'Rp 2.500.000',
      originalPrice: 'Rp 3.000.000',
      image: '/api/placeholder?width=400&height=300',
      duration: '4 Hari 3 Malam',
      location: 'Bali',
      rating: 4.8,
      reviews: 124,
      features: ['Hotel Bintang 4', 'Transportasi AC', 'Makan', 'Tour Guide']
    },
    {
      id: 2,
      title: 'Paket Raja Ampat 7H6M',
      price: 'Rp 8.500.000',
      originalPrice: 'Rp 10.000.000',
      image: '/api/placeholder?width=400&height=300',
      duration: '7 Hari 6 Malam',
      location: 'Papua Barat',
      rating: 4.9,
      reviews: 89,
      features: ['Resort', 'Snorkeling', 'Makan', 'Transportasi Kapal']
    },
    {
      id: 3,
      title: 'Paket Umrah 15H14M',
      price: 'Rp 25.000.000',
      originalPrice: 'Rp 28.000.000',
      image: '/api/placeholder?width=400&height=300',
      duration: '15 Hari 14 Malam',
      location: 'Mekah & Madinah',
      rating: 5.0,
      reviews: 256,
      features: ['Hotel Bintang 5', 'Visa Umrah', 'Makan', 'Tour Guide']
    }
  ]

  const testimonials = [
    {
      id: 1,
      name: 'Ahmad Wijaya',
      avatar: '/api/placeholder?width=50&height=50',
      rating: 5,
      comment: 'Pelayanan sangat memuaskan! Tour guide profesional dan destinasi sesuai ekspektasi.',
      package: 'Paket Bali 4H3M'
    },
    {
      id: 2,
      name: 'Siti Nurhaliza',
      avatar: '/api/placeholder?width=50&height=50',
      rating: 5,
      comment: 'Perjalanan Umrah yang sangat berkesan. Fasilitas lengkap dan pelayanan terbaik.',
      package: 'Paket Umrah 15H14M'
    },
    {
      id: 3,
      name: 'Budi Santoso',
      avatar: '/api/placeholder?width=50&height=50',
      rating: 4,
      comment: 'Raja Ampat sangat indah! Organisasi trip sangat baik dan terkoordinasi.',
      package: 'Paket Raja Ampat 7H6M'
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % heroImages.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [])

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' })
    }
    setIsMenuOpen(false)
  }

  const handleContactSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      const response = await fetch('/api/contact', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(contactForm),
      })
      
      const data = await response.json()
      
      if (response.ok) {
        setNotification({
          type: 'success',
          message: 'Pesan Anda telah terkirim. Kami akan segera menghubungi Anda!'
        })
        setContactForm({ name: '', email: '', subject: '', message: '' })
      } else {
        setNotification({
          type: 'error',
          message: data.error || 'Terjadi kesalahan. Silakan coba lagi.'
        })
      }
    } catch (error) {
      setNotification({
        type: 'error',
        message: 'Terjadi kesalahan koneksi. Silakan coba lagi.'
      })
    } finally {
      setIsLoading(false)
      setTimeout(() => setNotification(null), 5000)
    }
  }

  const handleBookingSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)
    
    try {
      const response = await fetch('/api/booking', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(bookingForm),
      })
      
      const data = await response.json()
      
      if (response.ok) {
        setNotification({
          type: 'success',
          message: `Pemesanan berhasil! Booking ID: ${data.bookingId}`
        })
        setShowBookingModal(false)
        setBookingForm({
          packageId: '',
          packageName: '',
          name: '',
          email: '',
          phone: '',
          departureDate: '',
          participants: 1,
          specialRequests: ''
        })
      } else {
        setNotification({
          type: 'error',
          message: data.error || 'Terjadi kesalahan. Silakan coba lagi.'
        })
      }
    } catch (error) {
      setNotification({
        type: 'error',
        message: 'Terjadi kesalahan koneksi. Silakan coba lagi.'
      })
    } finally {
      setIsLoading(false)
      setTimeout(() => setNotification(null), 5000)
    }
  }

  const openBookingModal = (pkg: any) => {
    setSelectedPackage(pkg)
    setBookingForm({
      packageId: pkg.id.toString(),
      packageName: pkg.title,
      name: '',
      email: '',
      phone: '',
      departureDate: '',
      participants: 1,
      specialRequests: ''
    })
    setShowBookingModal(true)
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Notification */}
      {notification && (
        <div className={`fixed top-20 right-4 z-50 p-4 rounded-lg shadow-lg max-w-sm animate-slide-in-up ${
          notification.type === 'success' ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
        }`}>
          <div className="flex items-center">
            {notification.type === 'success' ? (
              <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
            ) : (
              <AlertCircle className="h-5 w-5 text-red-600 mr-3" />
            )}
            <p className={`text-sm ${
              notification.type === 'success' ? 'text-green-800' : 'text-red-800'
            }`}>
              {notification.message}
            </p>
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <h1 className="text-2xl font-bold text-green-700">Insan Tour Alam</h1>
              </div>
            </div>
            
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Beranda</button>
                <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Tentang Kami</button>
                <button onClick={() => scrollToSection('packages')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Paket Tour</button>
                <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Galeri</button>
                <button onClick={() => scrollToSection('testimonials')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Testimoni</button>
                <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-green-600 px-3 py-2 rounded-md text-sm font-medium transition-colors">Kontak</button>
              </div>
            </div>
            
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="inline-flex items-center justify-center p-2 rounded-md text-gray-700 hover:text-green-600 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-green-500"
              >
                {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile menu */}
        {isMenuOpen && (
          <div className="md:hidden">
            <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-white border-t">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Beranda</button>
              <button onClick={() => scrollToSection('about')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Tentang Kami</button>
              <button onClick={() => scrollToSection('packages')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Paket Tour</button>
              <button onClick={() => scrollToSection('gallery')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Galeri</button>
              <button onClick={() => scrollToSection('testimonials')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Testimoni</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-green-600 block px-3 py-2 rounded-md text-base font-medium w-full text-left">Kontak</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative h-screen mt-16">
        <div className="absolute inset-0 overflow-hidden">
          {heroImages.map((image, index) => (
            <div
              key={index}
              className={`absolute inset-0 transition-opacity duration-1000 ${index === currentSlide ? 'opacity-100' : 'opacity-0'}`}
              style={{
                backgroundImage: `url(${image.url})`,
                backgroundSize: 'cover',
                backgroundPosition: 'center'
              }}
            >
              <div className="absolute inset-0 bg-black/40"></div>
            </div>
          ))}
        </div>
        
        <div className="relative h-full flex items-center justify-center text-center text-white px-4">
          <div className="max-w-4xl">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 animate-fade-in">
              {heroImages[currentSlide].title}
            </h1>
            <p className="text-xl md:text-2xl mb-8 animate-fade-in-delay">
              {heroImages[currentSlide].subtitle}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center animate-fade-in-delay-2">
              <Button size="lg" className="bg-green-600 hover:bg-green-700 text-white px-8 py-3 text-lg">
                <Calendar className="mr-2 h-5 w-5" />
                Pesan Sekarang
              </Button>
              <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-gray-900 px-8 py-3 text-lg">
                <Phone className="mr-2 h-5 w-5" />
                Hubungi Kami
              </Button>
            </div>
          </div>
        </div>

        {/* Slide Indicators */}
        <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {heroImages.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentSlide(index)}
              className={`w-3 h-3 rounded-full transition-colors ${index === currentSlide ? 'bg-white' : 'bg-white/50'}`}
            />
          ))}
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Tentang Insan Tour Alam</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Mitra terpercaya untuk perjalanan wisata domestik, internasional, dan umrah sejak 2010
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Mengapa Memilih Kami?</h3>
              <div className="space-y-4">
                <div className="flex items-start space-x-3">
                  <Shield className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Legalitas Terjamin</h4>
                    <p className="text-gray-600">Terdaftar resmi dengan izin lengkap dan asuransi perjalanan</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Users className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Pemandu Profesional</h4>
                    <p className="text-gray-600">Tour guide berpengalaman dan bersertifikat</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Hotel className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Fasilitas Terbaik</h4>
                    <p className="text-gray-600">Hotel bintang 4-5 dan transportasi nyaman</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <Camera className="h-6 w-6 text-green-600 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-semibold text-gray-900">Pengalaman Berharga</h4>
                    <p className="text-gray-600">Lebih dari 10.000 pelanggan puas sejak 2010</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-6">
              <Card className="text-center p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">500+</div>
                <p className="text-gray-600">Paket Wisata</p>
              </Card>
              <Card className="text-center p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">10K+</div>
                <p className="text-gray-600">Pelanggan Puas</p>
              </Card>
              <Card className="text-center p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">50+</div>
                <p className="text-gray-600">Destinasi</p>
              </Card>
              <Card className="text-center p-6">
                <div className="text-3xl font-bold text-green-600 mb-2">14+</div>
                <p className="text-gray-600">Tahun Pengalaman</p>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Packages Section */}
      <section id="packages" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Paket Tour Unggulan</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Pilih paket wisata terbaik untuk liburan impian Anda
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg) => (
              <Card key={pkg.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img src={pkg.image} alt={pkg.title} className="w-full h-48 object-cover" />
                  <Badge className="absolute top-4 left-4 bg-red-500">Diskon 17%</Badge>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl">{pkg.title}</CardTitle>
                  <CardDescription className="flex items-center text-gray-600">
                    <MapPin className="h-4 w-4 mr-1" />
                    {pkg.location}
                    <span className="mx-2">•</span>
                    <Calendar className="h-4 w-4 mr-1" />
                    {pkg.duration}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center mb-4">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star key={i} className={`h-4 w-4 ${i < Math.floor(pkg.rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                      ))}
                    </div>
                    <span className="ml-2 text-sm text-gray-600">{pkg.rating} ({pkg.reviews} ulasan)</span>
                  </div>
                  
                  <div className="mb-4">
                    <div className="flex items-baseline">
                      <span className="text-2xl font-bold text-green-600">{pkg.price}</span>
                      <span className="ml-2 text-sm text-gray-500 line-through">{pkg.originalPrice}</span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-6">
                    {pkg.features.map((feature, index) => (
                      <div key={index} className="flex items-center text-sm text-gray-600">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                        {feature}
                      </div>
                    ))}
                  </div>

                  <Button 
                    className="w-full bg-green-600 hover:bg-green-700"
                    onClick={() => openBookingModal(pkg)}
                  >
                    Pesan Sekarang
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" variant="outline" className="border-green-600 text-green-600 hover:bg-green-600 hover:text-white">
              Lihat Semua Paket
            </Button>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section id="gallery" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Galeri Perjalanan</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Dokumentasi momen indah bersama pelanggan setia kami
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="col-span-2 row-span-2 relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=600&height=600" alt="Raja Ampat" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-xl font-bold">Raja Ampat</h3>
                  <p className="text-sm">Papua Barat</p>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=300&height=300" alt="Tanah Lot Bali" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-bold">Tanah Lot</h3>
                  <p className="text-sm">Bali</p>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=300&height=300" alt="Borobudur" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-bold">Candi Borobudur</h3>
                  <p className="text-sm">Jawa Tengah</p>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=300&height=300" alt="Labuan Bajo" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-bold">Labuan Bajo</h3>
                  <p className="text-sm">NTT</p>
                </div>
              </div>
            </div>
            
            <div className="relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=300&height=300" alt="Kawah Putih" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-lg font-bold">Kawah Putih</h3>
                  <p className="text-sm">Jawa Barat</p>
                </div>
              </div>
            </div>
            
            <div className="col-span-2 relative overflow-hidden rounded-lg group cursor-pointer">
              <img src="/api/placeholder?width=600&height=300" alt="Ka'bah" className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                <div className="absolute bottom-4 left-4 text-white">
                  <h3 className="text-xl font-bold">Umrah</h3>
                  <p className="text-sm">Mekah & Madinah</p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button size="lg" variant="outline" className="border-green-600 text-green-600 hover:bg-green-600 hover:text-white">
              Lihat Semua Foto
            </Button>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Apa Kata Mereka?</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Testimoni dari pelanggan yang telah berpengalaman bersama kami
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial) => (
              <Card key={testimonial.id} className="p-6">
                <div className="flex items-center mb-4">
                  <img src={testimonial.avatar} alt={testimonial.name} className="w-12 h-12 rounded-full mr-4" />
                  <div>
                    <h4 className="font-semibold text-gray-900">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.package}</p>
                  </div>
                </div>
                <div className="flex mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className={`h-4 w-4 ${i < testimonial.rating ? 'text-yellow-400 fill-current' : 'text-gray-300'}`} />
                  ))}
                </div>
                <p className="text-gray-700 italic">"{testimonial.comment}"</p>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Hubungi Kami</h2>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Siap melayani dan membantu perjalanan impian Anda
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-6">Informasi Kontak</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-3">
                  <Phone className="h-6 w-6 text-green-600" />
                  <div>
                    <p className="font-semibold">Telepon</p>
                    <p className="text-gray-600">+62 21 1234 5678</p>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <MessageCircle className="h-6 w-6 text-green-600" />
                  <div>
                    <p className="font-semibold">WhatsApp</p>
                    <p className="text-gray-600">+62 812 3456 7890</p>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <MapPin className="h-6 w-6 text-green-600 mt-1" />
                  <div>
                    <p className="font-semibold">Alamat</p>
                    <p className="text-gray-600">Jl. Wisata Alam No. 123, Jakarta Selatan, 12345</p>
                  </div>
                </div>
              </div>

              <div className="mt-8">
                <h4 className="font-semibold text-gray-900 mb-4">Jam Operasional</h4>
                <div className="space-y-2 text-gray-600">
                  <p>Senin - Jumat: 09:00 - 18:00</p>
                  <p>Sabtu: 09:00 - 15:00</p>
                  <p>Minggu: Tutup</p>
                </div>
              </div>
            </div>

            <div>
              <Card className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-6">Kirim Pesan</h3>
                <form onSubmit={handleContactSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={contactForm.name}
                      onChange={(e) => setContactForm({...contactForm, name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({...contactForm, email: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Subjek</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={contactForm.subject}
                      onChange={(e) => setContactForm({...contactForm, subject: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Pesan</label>
                    <textarea 
                      rows={4} 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={contactForm.message}
                      onChange={(e) => setContactForm({...contactForm, message: e.target.value})}
                      required
                    ></textarea>
                  </div>
                  <Button type="submit" className="w-full bg-green-600 hover:bg-green-700" disabled={isLoading}>
                    {isLoading ? 'Mengirim...' : 'Kirim Pesan'}
                  </Button>
                </form>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* WhatsApp Floating Button */}
      <a
        href="https://wa.me/6281234567890"
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 bg-green-500 hover:bg-green-600 text-white p-4 rounded-full shadow-lg z-40 transition-colors"
      >
        <MessageCircle className="h-6 w-6" />
      </a>

      {/* Booking Modal */}
      {showBookingModal && selectedPackage && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-2xl font-bold text-gray-900">Form Pemesanan</h3>
                <button
                  onClick={() => setShowBookingModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>

              <div className="mb-6 p-4 bg-green-50 rounded-lg">
                <h4 className="font-semibold text-green-800 mb-2">{selectedPackage.title}</h4>
                <p className="text-green-600 text-sm">{selectedPackage.location} • {selectedPackage.duration}</p>
                <p className="text-green-700 font-bold mt-2">{selectedPackage.price}</p>
              </div>

              <form onSubmit={handleBookingSubmit} className="space-y-4">
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nama Lengkap</label>
                    <input 
                      type="text" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={bookingForm.name}
                      onChange={(e) => setBookingForm({...bookingForm, name: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                    <input 
                      type="email" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={bookingForm.email}
                      onChange={(e) => setBookingForm({...bookingForm, email: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nomor Telepon</label>
                    <input 
                      type="tel" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={bookingForm.phone}
                      onChange={(e) => setBookingForm({...bookingForm, phone: e.target.value})}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Tanggal Keberangkatan</label>
                    <input 
                      type="date" 
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                      value={bookingForm.departureDate}
                      onChange={(e) => setBookingForm({...bookingForm, departureDate: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Jumlah Peserta</label>
                  <select 
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    value={bookingForm.participants}
                    onChange={(e) => setBookingForm({...bookingForm, participants: parseInt(e.target.value)})}
                    required
                  >
                    {[...Array(10)].map((_, i) => (
                      <option key={i + 1} value={i + 1}>{i + 1} {i + 1 === 1 ? 'Orang' : 'Orang'}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Permintaan Khusus (Opsional)</label>
                  <textarea 
                    rows={3} 
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-green-500"
                    value={bookingForm.specialRequests}
                    onChange={(e) => setBookingForm({...bookingForm, specialRequests: e.target.value})}
                    placeholder="Contoh: Makanan khusus, kebutuhan khusus, dll."
                  ></textarea>
                </div>

                <div className="flex gap-4 pt-4">
                  <Button 
                    type="button" 
                    variant="outline" 
                    className="flex-1"
                    onClick={() => setShowBookingModal(false)}
                  >
                    Batal
                  </Button>
                  <Button 
                    type="submit" 
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    disabled={isLoading}
                  >
                    {isLoading ? 'Memproses...' : 'Konfirmasi Pemesanan'}
                  </Button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-green-400 mb-4">Insan Tour Alam</h3>
              <p className="text-gray-400">Mitra terpercaya untuk perjalanan wisata domestik, internasional, dan umrah.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Layanan</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Wisata Domestik</li>
                <li>Wisata Internasional</li>
                <li>Umrah & Haji</li>
                <li>Corporate Tour</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Perusahaan</h4>
              <ul className="space-y-2 text-gray-400">
                <li>Tentang Kami</li>
                <li>Testimoni</li>
                <li>Karir</li>
                <li>Blog</li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Ikuti Kami</h4>
              <div className="flex space-x-4">
                <div className="w-8 h-8 bg-gray-700 rounded-full"></div>
                <div className="w-8 h-8 bg-gray-700 rounded-full"></div>
                <div className="w-8 h-8 bg-gray-700 rounded-full"></div>
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 Insan Tour Alam. Hak Cipta Dilindungi.</p>
          </div>
        </div>
      </footer>

      <style jsx>{`
        @keyframes fade-in {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fade-in 1s ease-out;
        }
        .animate-fade-in-delay {
          animation: fade-in 1s ease-out 0.3s both;
        }
        .animate-fade-in-delay-2 {
          animation: fade-in 1s ease-out 0.6s both;
        }
      `}</style>
    </div>
  )
}